import base64
import json
from google.cloud import compute_v1


def hello_pubsub(event, context):
    """Triggered from a message on a Cloud Pub/Sub topic.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """
    print("event")
    print(event)
    instance_deleted = False
    pubsub_message = base64.b64decode(event['data']).decode('utf-8')
    json_pubsub_message = json.loads(pubsub_message)
    print(json_pubsub_message)
    project_id = json_pubsub_message["resource"]['labels']['project_id']
    zone = json_pubsub_message["resource"]['labels']['zone']
    machine_name = json_pubsub_message["protoPayload"]["request"]["name"]
    instance_client = compute_v1.InstancesClient()
    if "labels" in json_pubsub_message["protoPayload"]["request"].keys():
        for label in json_pubsub_message["protoPayload"]["request"]["labels"]:
            if label["key"] == "goog-dataproc-cluster-name" and \
                    "accessConfigs" in \
                    json_pubsub_message["protoPayload"]["request"]["networkInterfaces"][0].keys():
                    operation = instance_client.delete(project=project_id, zone=zone, instance=machine_name)
                    print(f"deleted vm {machine_name} in zone {zone} from project {project_id} because it was a "
                          f"DataProc VM with external IP ")
                    instance_deleted = True

    return instance_deleted